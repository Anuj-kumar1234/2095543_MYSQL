create database exercise2;
use exercise2;
create table student_info (Reg_Number varchar(20),Student_Name varchar(30),Branch varchar(20),Contact_Number varchar(20),DOB DATE,DOJ DATE,Address Varchar(250),Email_Id varchar(250));
create table subject_master(Subject_Code varchar(20),Subject_Name varchar(20),weightage int);
alter table student_info add primary key(Reg_Number);
alter table  subject_master add primary key(Subject_Code);
create table student_marks(Reg_Number varchar(20),Subject_code varchar(20),Semester_Number int,Marks_Number int);
drop table student_marks;
create table student_marks(Reg_Number varchar(20),Subject_code varchar(20),Semester_Number int,Marks_Number int,foreign key(Reg_Number) references student_info(Reg_Number),foreign key(Subject_Code) references subject_master(subject_code));
create table student_result(Reg_Number varchar(20),Semester_Number INT,GPA DECIMAL(5,3),IS_ELIGIBLE_SCHOLARSHIP CHAR(3));
USE EXERCISE2;
alter table student_result modify Semester_Number INT NOT NULL;
ALTER TABLE STUDENT_MARKS MODIFY MARKS_Number int DEFAULT 0 ;
ALTER TABLE STUDENT_RESULT MODIFY IS_ELIGIBLE_SCHOLARSHIP CHAR(3) DEFAULT 'YES';





