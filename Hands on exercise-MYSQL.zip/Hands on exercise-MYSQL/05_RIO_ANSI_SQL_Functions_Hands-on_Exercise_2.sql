use exercise2;
select student_name,branch ,upper(student_name),upper(branch) from student_info;
select lower(Subject_code) as lsubcode,lower(subject_name) as lsubname,weightage from subject_master;
select date_format(DOB,'%Y/%m/%d')AS req_format from student_info;
select date_format(DOB,'%M%D,%Y') as req_format1 from student_info;
select extract(year_month from dob) as date from student_info;
select student_name,contact_number,email_id,floor(period_diff(extract(year_month from current_date),extract(year_month from dob))/12) as age from student_info;
select m.reg_Number,s.student_name,avg(m.marks_Number) as Average_marks from student_info s , student_marks m where s.reg_Number=m.reg_Number;
select m.reg_Number,s.student_name,max(m.marks_Number) as Max_marks from student_info s , student_marks m where s.reg_Number=m.reg_Number;
select m.reg_Number,s.student_name,max(m.marks_Number) as Max_marks from student_info s , student_marks m where s.reg_Number=m.reg_Number and m.subject_code='EI05IP';
select avg(gpa),semester_number from student_result;
select *,ifnull(email_id,"no valid email address") from student_info; 
select *,
CASE
    WHEN branch = 'ece' THEN "Electronics and Communication Engineering"
    WHEN branch ='mba' THEN "Master of Business Administration"
    WHEN branch ='ei' THEN "Electronics Instrumentation"
    ELSE "Master of Computer Applications"
    end
    from student_info;


