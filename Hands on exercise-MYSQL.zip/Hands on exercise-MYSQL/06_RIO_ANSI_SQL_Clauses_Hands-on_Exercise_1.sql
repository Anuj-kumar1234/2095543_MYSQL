use exercises;
select start_date,count(associate_id) from associate_status group by start_date;
select start_date,count(associate_id) from associate_status where Trainer_Id='F004' group by start_date;
select start_date,count(associate_id)   from associate_status where Trainer_Id='F004'and count(associate_id)>2 group by start_date;
alter table   module_info modify column module_Duration int;
select * from module_info order by module_duration asc;
select aso.Associate_Name,m.module_Id,m.module_Name from module_info m,associate_info aso where m.Module_Id=aso.Module_Id ;

