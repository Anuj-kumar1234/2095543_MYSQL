use exercises;
drop table trainer_info;
set foreign_key_checks=0;
drop table trainer_info;
create table Trainer_info(Trainer_id varchar(20) ,Salutation varchar(7),Trainer_Name varchar(30),Trainer_Location varchar(30),Trainer_track varchar(15),Trainer_Qualification varchar(100),Trainer_Experience int, Trainer_Email varchar(100), Trainer_Password varchar(20),primary key(Trainer_Id));
insert into Trainer_Info values('F001','Mr.','Pankaj Gosh','pune','Java','Bachelor of technology',12,'Pankaj.Ghosh@alliance.com','fac1@123'),('F002','Mr.','Sanjay Radhakrishnan','Banglore','DoteNet','Bachelor of Technology',12,'Sanjay.Radhakrishnan@alliance.com','fac2@123'),('F003','Mr.','Vijay Mathur','Chennai','Mainframe','Bachelor of Technology',10,'Vijay.Mathur@alliance.com','fac3@123'),('F004','Mrs.','Nandini Nair','Kolkate','Java','Master of Computer Applications',9,'Nandini.Nair@Alliance.com','fac4@123'),('F005','Miss.','Anitha Parekh','Hyderabad','Testing','MCA',6,'Anitha.Parekh@alliance.com','fac5@123'),('F006','Mr.','Manoj Aggarwal','Mumbai','Mainframe','BTECH',9,'Manoj.Aggarwal@alliance.com','fac6@123'),('F007','Ms.','Meena Kulkarni','coimbatore','Testing','BTECH',5,'Meena.Kulkarni@alliance.com','fac7@123'),('F009','Mr.','Sagar Menon','Mumbai','Java','Msc It',12,'Sagar.Menon@allliance.com','fac8@123');
set foreign_key_checks=1;
insert into Trainer_info(Trainer_Id,Trainer_Name,Trainer_Email) values('F010','Sridhar',Null);
select * from Trainer_info where Trainer_Email=null; 
select Trainer_id,Trainer_Name,Trainer_track,Trainer_Location from Trainer_info where Trainer_Experience>4;
select * from module_info where Module_Duration>200;
select Trainer_Id,Trainer_Name from Trainer_info where Trainer_Qualification <>'bachelor of technology';
select Trainer_Id,Trainer_Name from Trainer_info where Trainer_Qualification <>'bachelor of technology' or Trainer_Qualification <> 'btech';
select * from module_info where module_duration between 200 and 300;
Select Trainer_Id,Trainer_name from Trainer_info where Trainer_name Like 'M%';
Select Trainer_Id,Trainer_name from Trainer_info where Trainer_name Like '%o%';
select module_name from module_info where module_name <> null;


