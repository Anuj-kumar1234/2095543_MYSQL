use exercise2;
alter table subject_master add   UNIQUE(subject_name);
ALTER table STUDENT_INFO ADD UNIQUE(Contact_Number);
INSERT INTO STUDENT_INFO(Reg_Number,DOB,DOJ) VALUES('1001','2001-02-02','2021-12-02');
INSERT INTO STUDENT_INFO(Reg_Number,DOB,DOJ) VALUES('1002','2021-12-02','2001-02-02');
Alter table student_info add constraint chk_ty check(DOB>DOJ);
INSERT INTO STUDENT_INFO(Reg_Number,DOB,DOJ) VALUES('1002','2021-12-02','2001-02-02');
use exercise2;
delete from student_info where reg_Number='1002';
INSERT INTO STUDENT_INFO(Reg_Number,DOB,DOJ) VALUES('1001','2001-02-02','2021-12-02');
Alter table student_MARKS add constraint chk_marks check(MARKS_Number>100);
Alter table student_RESULT add constraint chk_GPA check(GPA<=10);
Alter table student_RESULT add constraint chk_SCHOLAR check(IS_ELIGIBLE_SCHOLARSHIP='Y' OR IS_ELIGIBLE_SCHOLARSHIP='N');






