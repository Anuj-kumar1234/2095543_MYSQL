use exercise2;
set foreign_key_checks=0;
insert into student_info values('MC101301','James','MCA',9714589787,'1984-01-12','2010-07-08','No 10,South Block,Nivea','james.mca@yahoo.com'),('BEC11','Manio','ECE',8912457875,'1983-02-23','2011-06-22','8/12,Park View,Sieera','manioma@gmail.com'),('BEEI10','Mike','EI',8974567897,'1983-02-10','2010-08-10','Cross villa,NY','mike.james@ymail.com'),('MB111','Paulson','MBA',8547986123,'1984-12-19','2010-08-01','Lake view,NJ','paul.son@rediffmail.com');
set foreign_key_checks=0;
insert into student_info values('MC101301','James','MCA',9714589787,'1984-01-12','2010-07-08','No 10,South Block,Nivea','james.mca@yahoo.com'),('BEC11','Manio','ECE',8912457875,'1983-02-23','2011-06-22','8/12,Park View,Sieera','manioma@gmail.com'),('BEEI10','Mike','EI',8974567897,'1983-02-10','2010-08-10','Cross villa,NY','mike.james@ymail.com'),('MB111','Paulson','MBA',8547986123,'1984-12-19','2010-08-01','Lake view,NJ','paul.son@rediffmail.com');
alter table student_info drop check chk_ty;
insert into student_info values('MC101301','James','MCA',9714589787,'1984-01-12','2010-07-08','No 10,South Block,Nivea','james.mca@yahoo.com'),('BEC11','Manio','ECE',8912457875,'1983-02-23','2011-06-22','8/12,Park View,Sieera','manioma@gmail.com'),('BEEI10','Mike','EI',8974567897,'1983-02-10','2010-08-10','Cross villa,NY','mike.james@ymail.com'),('MB111','Paulson','MBA',8547986123,'1984-12-19','2010-08-01','Lake view,NJ','paul.son@rediffmail.com');
insert into Subject_Master values('EE01DCF','DCF',30),('EC02MUP','Microprocessor',40),('MC06DIP','Marketing',20),('EI05IP','Instrumentation Precision',40);
alter table subject_master modify column subject_name varchar(40);
insert into student_marks values('MC101301','EE01DCF',1,75),('MC101301','EC02MUP',1,65),('BEC11','EE01DCF',1,55),('BEC11','EE01DCF',1,55),('MB111','EE01DCF',1,65),('MB111','EC02MUP',1,68);
insert into student_result values('MC101301',1,7.5,'Y'),('BEC11',1,7.1,'Y'),('MB111',1,6.5,'N');
select * from student_info where email_Id <> null;
select reg_number,marks_number from student_marks where Marks_Number>50;
alter table student_marks drop check chk_marks;
select student_info.reg_number,student_info.student_name,subject_master.subject_name from subject_master,student_info;
delete from student_info where Reg_Number='1002'; 
select reg_Number,gpa,is_eligible_scholarship from student_result   order by  is_eligible_scholarship desc;
select s.reg_Number,s.student_name,ma.Marks_Number ,((ma.Marks_Number)*(m.weightage))/100 as weighted_marks from student_info s,subject_master m,student_marks ma ;
select * from student_info where student_Name like 'M%';
select s.student_name,s.reg_Number,m.marks_number from student_info s,student_marks m;
select s.student_name,s.reg_Number,m.marks_number from student_info s,student_marks m where m.marks_number between 60 and 100;
select s.student_name,s.reg_Number,m.marks_number from student_info s,student_marks m where s.student_name not like 'j%' ;
select s.student_name,s.reg_Number,m.marks_number from student_info s,student_marks m where m.subject_code IN('EE01DCF','EC02MUP');
SELECT * from student_info where student_name like '%on';











