use exercise2;
select s.reg_Number,s.student_name,r.GPA from student_info s, student_result r where s.Reg_Number=r.Reg_Number order by r.gpa desc;
select * from student_info order by Student_Name asc;
select *,floor(period_diff(extract(year_month from current_date),extract(year_month from dob))/12) as age from student_info order by age asc;
select s.reg_Number,s.student_name,r.GPA,r.semester_number from student_info s, student_result r where s.Reg_Number=r.Reg_Number order by r.gpa desc;
select reg_Number,Gpa,IS_ELIGIBLE_SCHOLARSHIP from student_result order by IS_ELIGIBLE_SCHOLARSHIP desc;
select *,max(gpa) from student_info s,student_result r where s.Reg_Number=r.Reg_Number group by r.Semester_Number;
select *,min(gpa) from student_info s,student_result r where s.Reg_Number=r.Reg_Number group by r.Semester_Number;

