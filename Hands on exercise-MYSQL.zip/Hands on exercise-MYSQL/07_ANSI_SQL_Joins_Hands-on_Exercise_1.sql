use exercises;
select t.trainer_id,b.batch_id from trainer_info t cross join batch_info b ;
select * from associate_status as a inner join batch_info as b on a.batch_id=b.batch_id;
select a.associate_id,t.trainer_id from associate_status as a right outer join trainer_info as  t on a.associate_id=t.trainer_id;
select a.associate_id,t.trainer_id from associate_status as a left outer join trainer_info as  t on a.associate_id=t.trainer_id;
set foreign_key_checks=0;
insert into associate_status(associate_id, module_id, batch_id) values('A007','EM004', 'B001');
set foreign_key_checks=1;
select ass.associate_id, ti.trainer_id from trainer_info as ti
left outer join associate_status as ass on ass.Trainer_Id = ti.trainer_id
union 
select ass.associate_id, ti.trainer_id from trainer_info as ti
right outer join associate_status as ass on ass.Trainer_Id = ti.trainer_id;

